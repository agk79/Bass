# netdiffuser-sunbelt2019

Here you will find the materials for the netdiffuseR workshop at Sunbelt2019. The whole website was built using `rmarkdown`, and the website itself can be found at https://usccana.github.io/netdiffuser-sunbelt2018. Datasets are to be found at [docs], and the source code as the `Rmd` files in this repository.

A permanent link to this version (will change in the future) is

https://github.com/usccana/netdiffuser-sunbelt2018/tree/sunbelt2019

For previous versions take a look at

https://github.com/usccana/netdiffuser-sunbelt2018/tree/sunbelt2018
